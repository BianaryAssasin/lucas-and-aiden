const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { useMainPlayer, useQueue } = require('discord-player');
const { songs } = require("../../data/playlists.json");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('list')
		.setDescription("shows the list of favorite songs"),
	async execute(interaction) {
            let player = useMainPlayer();
            let queue = useQueue(interaction.guild)

            let string = "";
            for (let i = 0; i < songs.length; i += 1) {
                string += `${songs[i].id}, ${songs[i].name}\n`
            }

            string += "\nPlease type the Id for the song you would like to play."

            let embd = new EmbedBuilder()
                            .setTitle("Play List")
                            .setDescription(string);
            await interaction.reply({ embeds: [embd] });
            
            const filters = msg => msg.author.id == interaction.user.id;
        
            interaction.channel.awaitMessages({ filters, max: 1, time: 5000 })
            .then(async Collected => {
                let value = await Collected.first()
            
                if (Number(value.content) <= songs.length && Number(value.content) != 0) {
                    for (let i = 0; i < songs.length; i += 1) {
                        if (Number(value.content) == songs[i].id) {
                            const { track } = await player.play(interaction.member.voice.channel, songs[i].name, {
                                nodeOptions: {
                                    metadata: interaction
                                }
                            });

                            const Embed = new EmbedBuilder()
                                                .setTitle("Now Queuing")
                                                .setDescription(`Title: ${track.title}`);

                            interaction.channel.send({ embeds: [Embed] });
                        }
                    }            
                } else {
                    await interaction.followUp({ content: "Sorry We couldn't find that song please try agein" })
                }
            })
        }
}