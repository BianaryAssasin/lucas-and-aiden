const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const { useMainPlayer } = require('discord-player');
const { music_permissions } = require("../../config.json");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('play')
		.setDescription("plays the song of your choice")
        .addStringOption(option =>
            option
                .setName("song")
                .setDescription("pick a song to play")
                .setRequired(true)),
	async execute(interaction) {
            let song = interaction.options.getString("song");
            let player = useMainPlayer();

            await interaction.deferReply();
            if(!music_permissions.BlackListed_Channels.includes(interaction.member.voice.channel.id)) {
                const { track } = await player.play(interaction.member.voice.channel, song, {
                    nodeOptions: {
                        metadata: interaction
                    }
                });
                const Embd = new EmbedBuilder()
                                .setTitle("New Queue")
                                .setDescription(`User: <@${interaction.user.id}>\n has jsut queued: ${track.title}`)
                                .setColor("#9966ff");
                
                const save = new ButtonBuilder()
                                .setCustomId("save")
                                .setLabel("Save")
                                .setStyle(ButtonStyle.Success);
                const volumUp = new ButtonBuilder()
                                    .setCustomId("up")
                                    .setLabel("🔊")
                                    .setStyle(ButtonStyle.Primary);
                const volumDown = new ButtonBuilder()
                                    .setCustomId("down")
                                    .setLabel("🔈")
                                    .setStyle(ButtonStyle.Primary);

                        const row = new ActionRowBuilder()
                                        .addComponents(save, volumDown, volumUp);

                interaction.followUp({ embeds: [Embd], components: [row] });
            } else {
                interaction.followUp({ content: "Sorry but this is a blacklisted channel there for you cant play music here" });
            }
        }
}