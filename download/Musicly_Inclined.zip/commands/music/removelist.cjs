const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { useMainPlayer, useQueue } = require('discord-player');
const { songs } = require("../../data/playlists.json");
const fs = require("fs/promises");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('removelist')
        .setDescription("removes a song from your list"),
    async execute(interaction) {
            let player = useMainPlayer(interaction.guild);
            let queue = useQueue(interaction.guild)

            let string = "";

            let data = await fs.readFile('data/playlists.json');
            let parse = JSON.parse(data);

            parse.songs.forEach((song, index) => {
                // index +1 so that the number starts at 1, easier for users.
                string += `${index + 1}, ${song.name}\n`
            })
        
            string += '\nPlease type the id of the song you want to remove'

            const Embd = new EmbedBuilder()
                                .setTitle("Remove Song")
                                .setDescription(string);
                                
                                
            await interaction.reply({ embeds: [Embd] });

            const filters = msg => msg.author.id == interaction.user.id;
        
            interaction.channel.awaitMessages({ filters, max: 1, time: 5000 })
            .then(async Collected => {
                let value = await Collected.first()

                const songNumber = Number(value.content)
                
                // songNumber <= as we increased the index by 1 above.
                if(songNumber > 0 && songNumber <= parse.songs.length && parse.songs.length != 0) {
                    parse.songs.splice(songNumber - 1, 1)

                    const str = JSON.stringify(parse, null, 2);
                    await fs.writeFile("data/playlists.json", str);
                    
                    interaction.channel.send({ content: `Item: ${value.content} has been removed!` });

                } else {
                    await interaction.followUp({ content: "Sorry We couldn't find that song please try agein. note this also ocurs when there is nothing left to remove" })
                }

            })
        }
}