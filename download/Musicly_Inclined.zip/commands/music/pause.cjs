const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const { useMainPlayer, useTimeline } = require('discord-player');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('pause')
		.setDescription("pauses the song"),
	async execute(interaction) {
            let time = useTimeline(interaction.guild);
            let player = useMainPlayer();
            
            time.pause();

            interaction.reply({ content: "Song has been paused!" })
        }
}