const { SlashCommandBuilder } = require("discord.js");
const { useTimeline } = require('discord-player');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('resume')
		.setDescription("resumes the song"),
	async execute(interaction) {
            let time = useTimeline(interaction.guild);
            
            time.resume();

            interaction.reply({ content: "Song has been resumed!" })
        }
}