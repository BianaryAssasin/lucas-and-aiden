const { Events } = require('discord.js');
const { Statuses } = require("../config.json");

module.exports = {
	name: Events.ClientReady,
	async execute(client) {
        client.user.setStatus(Statuses.Type);
        client.user.setPresence({ activities: [{ name: Statuses.message }] })
	},
};