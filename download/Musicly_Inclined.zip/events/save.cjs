const { Events } = require('discord.js');
const { useMainPlayer, useQueue, useTimeline } = require('discord-player');
const fs = require("fs/promises");
const { music_permissions } = require("../config.json");

module.exports = {
	name: Events.InteractionCreate,
	async execute(interaction) {
            if(interaction.type == 3) {
                let queue = useQueue(interaction.guild);
                let timeline = useTimeline(interaction.guild);
            if(interaction.customId == "save") {
                if (interaction.member.roles.cache.has(music_permissions.save_music.RoleId) && music_permissions.save_music.isEnabled) {
                    let data = await fs.readFile("data/playlists.json", "utf-8");

                    let parsed = JSON.parse(data);
                    
                    if(parsed.songs.length != 5) {
                        let name = queue.currentTrack.title;
                    let id = parsed.songs.length + 1;
    
                    parsed.songs.push({
                        name: name,
                        id: id
                    })
                    let string = JSON.stringify(parsed, null, 2);
    
                    await fs.writeFile("data/playlists.json", string);
                    } else {
                        interaction.reply({ content: "Sorry you can only save 5 songs" })
                    }
                    
                } else {
                    console.log("didnt work")
                }
            }
        }
	},
};