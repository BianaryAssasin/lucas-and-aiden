const { Events } = require('discord.js');
const { useMainPlayer, useQueue, useTimeline } = require('discord-player');

module.exports = {
	name: Events.InteractionCreate,
	async execute(interaction) {
        if(interaction.type == 3) {
                let queue = useQueue(interaction.guild);
                let timeline = useTimeline(interaction.guild);
            if(interaction.customId == "up") {
                if (timeline.volume >= 100) {
                    interaction.reply({ content: "Sorry but the valume is already at its highest" });

                } else {
                    let volume = timeline.volume + 10;
                timeline.setVolume(volume);

                interaction.reply({ content: `Volume is now at: ${timeline.volume}`, ephemeral: true });
                }
            } else if(interaction.customId == "down") {
                if (timeline.volume <= 0) {
                    interaction.reply({ content: "Sorry but the valume is already at its lowest" });
                } else {
                    let volume = timeline.volume - 10;
                    timeline.setVolume(volume);

                    interaction.reply({ content: `Volume is now at: ${timeline.volume}`, ephemeral: true })
                }
                
            }
        }
	},
};